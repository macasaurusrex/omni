# Ionicons

#### The premium icon font for [Ionic Framework](http://ionicframework.com/)


## License

Ionicons is licensed under the [MIT license](http://opensource.org/licenses/MIT).
